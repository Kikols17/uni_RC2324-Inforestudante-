
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <semaphore.h>
#include <fcntl.h>

#include "file_manager.h"

#ifndef BUF_SIZE
#define BUF_SIZE 1024
#endif

sem_t *config_sem;

int main() {
    char *filename = "class_config.config";

    config_sem = sem_open("config_sem", O_CREAT, 0666, 1);
    if (config_sem == SEM_FAILED) {
        printf("Error creating semaphore.\n");
    } else {
        printf("Checking file integrity...\n");
        int ret = file_checkintegrity(filename);
        if (ret == 0) {
            printf("File is correct.\n");
        } else if (ret == -1) {
            printf("File not found.\n");
        } else if (ret == -2) {
            printf("Incorrect amount of arguments.\n");
        } else if (ret == -3) {
            printf("Incorrect type.\n");
        }

        printf("Adding user1...\n");
        ret = file_adduser(filename, "user1", "pass1", "aluno");
        if (ret == 1) {
            printf("User already exists.\n");
        } else if (ret == 0) {
            printf("User added.\n");
        } else if (ret == -1) {
            printf("File not found.\n");
        } else if (ret == -2) {
            printf("Incorrect amount of arguments.\n");
        }

        printf("Adding user2...\n");
        ret = file_adduser(filename, "user2", "pass2", "aluno");
        if (ret == 1) {
            printf("User already exists.\n");
        } else if (ret == 0) {
            printf("User added.\n");
        } else if (ret == -1) {
            printf("File not found.\n");
        } else if (ret == -2) {
            printf("Incorrect amount of arguments.\n");
        }

        char type[BUF_SIZE];
        printf("Finding user1...\n");
        ret = file_finduser(filename, "user1", "pass1", type);
        if (ret == 1) {
            printf("User not found.\n");
        } else if (ret == 0) {
            printf("User found, password match.\n");
        } else if (ret == -1) {
            printf("File not found.\n");
        } else if (ret == -2) {
            printf("Incorrect amount of arguments.\n");
        }

        printf("Finding user3...\n");
        ret = file_finduser(filename, "user3", "pass1", type);
        if (ret == 1) {
            printf("User not found\n");
        } else if (ret == 0) {
            printf("User found, password match.\n");
        } else if (ret == -1) {
            printf("File not found.\n");
        } else if (ret == -2) {
            printf("Incorrect amount of arguments.\n");
        }

        printf("Removing user1...\n");
        ret = file_removeuser(filename, "user1");
        if (ret == 1) {
            printf("User not found.\n");
        } else if (ret == 0) {
            printf("User removed.\n");
        } else if (ret == -1) {
            printf("File not found.\n");
        } else if (ret == -2) {
            printf("Incorrect amount of arguments.\n");
        }
    }

    // close sem
    sem_close(config_sem);
    sem_unlink("config_sem");
    return 0;
}